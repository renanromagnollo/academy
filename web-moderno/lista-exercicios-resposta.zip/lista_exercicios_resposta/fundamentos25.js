function contador () {
    for (let i = 1; i<=50; i++) {
        console.log(i);
    }
}
contador()